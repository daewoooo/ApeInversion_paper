## FISH inversion validation for the study: 'Recurrent inversion toggling and great ape genome evolution'.
This folder contains high-resolution images of FISH experiments that are part of the Figure S5.

## Subfolder Raw_images
This folder contains high-resolution images of FISH experiments inclusing DAPI, Cy3, Cy5 and fluorescein fluorescence signals.

## Note
See the publication for more details.
