## FISH inversion validation for the study: 'Recurrent inversion toggling and great ape genome evolution'.
This folder contains high-resolution images of FISH experiments that are part of the Figure S5.

## Subfolder Raw_images
This folder contains high-resolution images of FISH experiments including DAPI, Cy3 (red), Cy5 (blue) and fluorescein (green) fluorescence signals.

## Note
See the publication for more details.
